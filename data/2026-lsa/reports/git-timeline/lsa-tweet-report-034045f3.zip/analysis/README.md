# TODO Analysis

* Check Basic Consistency of Data (Totals across rows, Totals across Columns)
* Check Deltas to prior Versions, show news
* Basic stats: min, max, mean
* Calculation of relative numbers based on absolute numbers published
* Chart results

## Sachsen-Anhalt 2026 Git audit

The reproducible election-night audit is in [lsa_git_audit.ipynb](lsa_git_audit.ipynb).
Its frozen 98.27% [tweet report](../data/2026-lsa/reports/git-timeline/034045f3/REPORT.md)
includes 13 baseline PNGs, a complete revision ledger, and the
[Bitterfeld-Wolfen party comparison](../data/2026-lsa/reports/git-timeline/034045f3/BITTERFELD_WOLFEN_000028.md).
The latter contains municipality totals; individual votes for district 000028
were not archived and cannot be isolated from the reporting batch.

The [Aken 000010 addendum](../data/2026-lsa/reports/git-timeline/034045f3/AKEN_000010.md)
adds two German tweet drafts and a fourteenth image. It identifies the added
district behind 2,660 → 2,661, first seen in the 7 September 00:51:10 MESZ
archive run after absence at 00:45:41. Exact HTML-fetch timestamps, source
hashes and the distinction from the frozen baseline are retained in the detail.

Run `python3 scripts/analyze_lsa_git_timeline.py --ref COMMIT` from the repository
root, followed by `python3 scripts/render_lsa_tweet_report.py --input REPORT_DIR`.
The analyzer uses only the standard library; rendering requires Matplotlib and
NumPy. Neither command collects live data or publishes anything.
Use `--require-complete` on the analyzer for the full-data rerun and `--baseline`
on the renderer to compare with the frozen report. Exact commands, source
hashes, definitions, and limitations are in the report's `METHODS.md`.

To restore the addendum after rendering the baseline, keep its bundled
`addendum_sources/aken_capture_bundle.json` in the report folder and run
`python3 scripts/add_lsa_aken_update.py --input data/2026-lsa/reports/git-timeline/034045f3`.
This command verifies the retained sources and regenerates the addendum offline.
