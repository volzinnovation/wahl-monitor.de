#!/usr/bin/env python3
"""Check generated evidence, draft lengths, links, and an independent rerun."""
import argparse
import csv
import gzip
import hashlib
import json
import re
from pathlib import Path


def verify(path, reproduction=None, visual_reviewed=False):
    s=json.loads((path/'summary.json').read_text())
    tweets=json.loads((path/'tweets.json').read_text())
    charts=json.loads((path/'chart_map.json').read_text())
    assert not s['arithmetic_issues'], 'Arithmetic violations require review'
    assert not s['source_replay_differences'], 'Source replay differences require review'
    assert s['aggregation_nonzero']==0 and s['mode_nonzero']==0, 'Aggregation differences require review'
    assert all(x['verified'] for x in json.loads((path/'source_manifest.json').read_text()))
    for t in tweets:
        weight=sum(1 if ord(c)<=0x10ff or 0x2000<=ord(c)<=0x200d or 0x2010<=ord(c)<=0x201f or 0x2032<=ord(c)<=0x2037 else 2 for c in t['text'])
        assert weight==t['weighted_characters'] and weight<=280
        assert len(t['images'])==len(t['alt_text'])
        for image in t['images']:assert (path/image).is_file()
    for c in charts:assert (path/c['path']).read_bytes().startswith(b'\x89PNG\r\n\x1a\n')
    for name in ['REPORT.md','BITTERFELD_WOLFEN_000028.md','METHODS.md'] + (['AKEN_000010.md'] if (path/'AKEN_000010.md').exists() else []):
        for target in re.findall(r'\]\(([^)]+)\)',(path/name).read_text()):
            if target.startswith(('https://','http://')) or target=='VALIDATION.md':continue
            assert (path/target).is_file(), f'Broken link {target}'
    case=json.loads((path/'bitterfeld_case.json').read_text())
    assert case['district_vote_diff_available'] is False
    assert len(case['simultaneously_reported_municipality_districts'])>1
    before,after=case['municipality_before'],case['municipality_after']
    for prefix,field in [('D','valid_votes_erst'),('F','valid_votes_zweit')]:
        rows=[r for r in case['aggregate_party_diffs'] if r['scope']==before['area_key'] and r['party_code'].startswith(prefix)]
        assert sum(r['delta'] for r in rows)==after[field]-before[field]
    with gzip.open(path/'aggregation_checks.csv.gz','rt') as f:aggregates=list(csv.DictReader(f))
    assert len(aggregates)==s['aggregation_checks']
    assert all(r['delta'] in ('','0') for r in aggregates)
    addendum = None
    if (path/'aken_case.json').exists():
        from add_lsa_aken_update import derive
        derived = derive(path)
        assert derived == json.loads((path/'aken_case.json').read_text()), 'Aken evidence differs from source replay'
        assert derived['before']['overview_total'] == 2660
        assert derived['after']['overview_total'] == 2661
        assert len([t for t in tweets if t.get('series') == 'aken_addendum']) == 2
        addendum = {'captures':len(derived['observations']), 'verified_git_files':len(derived['sources']),
                    'baseline_status_rows_checked':derived['baseline_status_rows_checked'],
                    'first_present_capture_local':derived['after']['capture_local'],
                    'source_replay':'passed'}
    compared=[]
    if reproduction:
        for other in sorted(reproduction.iterdir()):
            if not other.is_file() or not (path/other.name).is_file():continue
            if other.name in ['REPORT.md','comparison.json','VALIDATION.md','verification.json','SHA256SUMS']:continue
            assert other.read_bytes()==(path/other.name).read_bytes(), f'Reproduction differs: {other.name}'
            compared.append(other.name)
        if (reproduction/'charts').exists():
            for other in sorted((reproduction/'charts').glob('*.png')):
                assert other.read_bytes()==(path/'charts'/other.name).read_bytes(), f'Chart differs: {other.name}'
                compared.append('charts/'+other.name)
        for other in sorted((reproduction/'addendum_sources').glob('*.json')):
            assert other.read_bytes() == (path/'addendum_sources'/other.name).read_bytes()
            compared.append('addendum_sources/'+other.name)
        if addendum:
            assert (reproduction/'REPORT.md').read_bytes() == (path/'REPORT.md').read_bytes(), 'Updated report differs'
            compared.append('REPORT.md')
    results={'confidence':'Share with caveats','structural_checks':'passed',
             'tweet_count':len(tweets),'chart_count':len(charts),'max_weighted_tweet_length':max(t['weighted_characters'] for t in tweets),
             'reproduction_files_compared':compared,'visual_reviewed':visual_reviewed,
             'verifier_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    if addendum: results['aken_addendum'] = addendum
    (path/'verification.json').write_text(json.dumps(results,indent=2,ensure_ascii=False,sort_keys=True)+'\n')
    lines=['# Validation report','','## Overall assessment: Share with caveats','',
           'The interim report answers the archived-data question. It does not establish election misconduct or reconstruct votes for district 000028.','',
           '## Checks completed','',
           f"- {s['retained_sources_verified']} source objects match the archived SHA-256 manifests.",
           f"- {len(s['arithmetic_issues'])} arithmetic violations; {len(s['source_replay_differences'])} normalized/source differences.",
           f"- {s['aggregation_checks']:,} geographic and {s['mode_checks']:,} U+B field comparisons; zero non-null residuals. Repeated states are included.",
           f"- {len(tweets)} tweet drafts; maximum {results['max_weighted_tweet_length']} weighted characters; all local links resolve.",
           f"- {len(charts)} PNGs; visual review recorded: {visual_reviewed}.",
           f"- Independent rerun: {len(compared)} byte-identical files; exact list in verification.json.",
           '- Bitterfeld municipality party deltas reconcile to first- and second-vote total deltas separately. District attribution is explicitly unavailable.','',
           '## Independent checks and regression tests','',
           'The companion notebook parses original CSVs independently, recomputes municipality and party totals against Land, and reads the overview JSON at both Bitterfeld captures. All five code cells executed sequentially with Python. A Jupyter kernel runner was unavailable locally (nbformat/nbclient missing); no dependencies were installed.','',
           "`python3 -m unittest discover -s scripts -p test_lsa_git_timeline.py -v` passes 12 tests covering growth, redistribution, missing vs zero, resets, initial templates, row order, arithmetic, separate geographic sums, the completeness guard, and future booth U/B grouping. The CLI `--require-complete` also correctly returned nonzero on this 2614/2660 snapshot. Initial implementation and notebook syntax errors were fixed before this validation. No source data was altered to pass checks.",'',
           '## Required caveats','',
           '- Reporting completeness is not vote completeness or official certification.',
           '- District-status history starts at 19:05; original district vote rows were absent.',
           '- Bitterfeld 000028 returns with four other districts. Municipality deltas cannot be assigned to it.',
           '- HTML/CSV publication timing can differ. Source lag is not a count of lost ballots.',
           '- Changes between captures and offsetting revisions can remain unseen; arithmetic alone cannot identify causes or rule out substantive errors.','',
           'No remaining blocker to a labelled interim report. Missing historical district vote data blocks individual-district party attribution. No tweets or website were published.','']
    if addendum:
        lines.extend(['## Aken addendum validation','',
                      f"- Replayed {addendum['captures']} post-baseline HTML observations; verified all {addendum['verified_git_files']} retained files against Git blob hashes and every HTML file against its collector SHA-256 and byte count.",
                      f"- Checked {addendum['baseline_status_rows_checked']:,} baseline status rows for any earlier occurrence of Aken 000010; none found.",
                      '- Exactly one added identity and no removed identities in the adjacent captures; total districts increase 2660 to 2661. Both HTML and CSV metadata confirm the changed total.',
                      '- First presence is in the 00:51:10 MESZ archive run, following absence at 00:45:41. Exact HTML-fetch times are retained separately; neither timestamp is asserted to be the precise publication time.',
                      '- The original 15 tweets and baseline evidence remain unchanged. Two addendum tweets and one image cover only this later finding; statewide vote shares and anomaly counts were not rerun.',
                      '- The addendum was rebuilt independently from the original report package and bundled sources; its generated report, data and image were compared byte-for-byte.',
                      '- Individual precinct party votes and the reason for adding the entry remain unavailable in these sources.',''])
    (path/'VALIDATION.md').write_text('\n'.join(lines))
    print(json.dumps(results,ensure_ascii=False,indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--reproduction-dir',type=Path)
    p.add_argument('--visual-reviewed',action='store_true')
    a=p.parse_args();verify(a.input,a.reproduction_dir,a.visual_reviewed)
